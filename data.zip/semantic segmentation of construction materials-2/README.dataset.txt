# semantic segmentation of construction materials > 2025-07-01 12:11pm
https://universe.roboflow.com/construction-material-detection/semantic-segmentation-of-construction-materials

Provided by a Roboflow user
License: CC BY 4.0

